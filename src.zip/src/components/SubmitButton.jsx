const SubmitButton = () => {
  return (
    <button className="submit-btn">
      📅 Book Free Demo!
    </button>
  );
};

export default SubmitButton;
